import {
  Component,
  OnInit,
} from '@angular/core';
import {
  ListarService
} from 'src/app/Service/listar.service';
import {
  Persona
} from 'src/app/interfaces/persona.interface';
import Swal from 'sweetalert2';
import {
  prependOnceListener
} from 'process';
import {
  EditService
} from 'src/app/Service/edit.service';
import {
  EliminarService
} from 'src/app/Service/eliminar.service';

@Component({
  selector: 'app-listar',
  templateUrl: './listar.component.html',
  styleUrls: ['./listar.component.css']
})
export class ListarComponent implements OnInit {
  personas: Persona[];
  mostrar = false;

  constructor(private listar: ListarService, private editar: EditService, private del: EliminarService) {
    this.listar.get().subscribe((data: Persona[]) => {
      console.log(data);
      this.personas = data;
      if (this.personas !== null && this.personas !== undefined) {
        this.mostrar = true;
      } else {
        this.mostrar = false;
      }
    });
  }

  ngOnInit(): void {}

  listarDataFromDB() {
    this.listar.get().subscribe((data: Persona[]) => {
      console.log('Entro');
      this.personas = data;
      if (this.personas.length > 0) {
        this.mostrar = true;
      } else {
        this.mostrar = false;
      }
    });
  }

  async editarPersona(persona: Persona, indice: number) {
    const {
      value: formValues
    } = await Swal.fire({
      title: 'Editar Persona',
      html:
        //uso html para agregar las cajas al popup
        `
          <input id="swal-input1" class="swal2-input" value="${persona.id}">
          <input id="swal-input2" class="swal2-input"   value="${persona.nombre}">
          <input id="swal-input3" class="swal2-input" value="${persona.apellidos}">
          <input id="swal-input4" class="swal2-input" value="${persona.idSexo}">
          <input id="swal-input5" class="swal2-input" value="${persona.edad}">
        `,
      focusConfirm: false,
      confirmButtonText: 'Editar',
      showCancelButton: true,
      cancelButtonText: 'Cancelar',
      preConfirm: () => { // Le paso los datos a la variable formValues
        return [
          // Obtengo el valor para cada elemento del Popup con js y lo deja en una posición
          (document.getElementById('swal-input1') as HTMLInputElement).value,
          (document.getElementById('swal-input2') as HTMLInputElement).value,
          (document.getElementById('swal-input3') as HTMLInputElement).value,
          (document.getElementById('swal-input4') as HTMLInputElement).value,
          (document.getElementById('swal-input5') as HTMLInputElement).value,
        ]
      }
    })

    if (formValues) {
      //Swal.fire(JSON.stringify(formValues));
      const p = {
        id: formValues[0],
        nombre: formValues[1],
        apellidos: formValues[2],
        idSexo: formValues[3],
        edad: formValues[4]
      };
      // Permite actualizar la tabla sin refrescar la página
      this.personas[indice] = p as any;

      // Envío el objeto al servicio
      this.editar.post(p).subscribe(console.log);
    }
  }

  eliminar(id: number) {
    Swal.fire({
      title: '¿Estás seguro que sea borrar?',
      text: "Esta acción no se puede revertir!",
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Borrar',
      cancelButtonText: 'Cancelar'
    }).then((result) => {
      if (result.value) {
        this.del.delete(id).subscribe((ok) => {
          Swal.fire(
            'Eliminado!',
            'La persona ha sido borrada correctamente',
            'success'
          )
        }, err => {
          Swal.fire(
            'Error!',
            'Algún error inesperado ha ocurrido!',
            'error'
          )
        });
      }
    });
  }
}