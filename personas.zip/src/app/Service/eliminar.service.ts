import {
  Injectable
} from '@angular/core';
import {
  HttpClient
} from '@angular/common/http';
import {
  environment
} from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class EliminarService {

  constructor(private http: HttpClient) {}

  delete(id: number) {
    // http.request es el genérico en las funciones CRUD
    return this.http.request('delete', environment.base_Url + 'eliminar', {
      body: {
        id
      }
    })
  }
}