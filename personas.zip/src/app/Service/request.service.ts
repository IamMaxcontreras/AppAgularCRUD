import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';



@Injectable({
  providedIn: 'root'
})
export class RequestService {

  constructor(private http:HttpClient) { }
  post(persona: object = {}){
    //debo mejorar esto para pasar la base_url como el profe  :/
    return this.http.post<any>(`http://localhost:10300/persona/crear`, persona);
  }
}

//creo mi interface con la estructura de la tabla
export interface Persona{
  nombre:string;
  apellidos:string;
  idSexo:number;
  edad:number;
}

