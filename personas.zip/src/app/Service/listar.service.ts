import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Persona } from '../interfaces/persona.interface';

@Injectable({
  providedIn: 'root'
})
export class ListarService {
  getPersonas() {
   // throw new Error("Method not implemented.");
  }
  constructor(private http:HttpClient) { }
  Url='http://localhost:10300/persona/listar'
  post(persona: object = {}){
    //debo mejorar esto para pasar la base_url como el profe  :/
    return this.http.get<any>(`http://localhost:10300/persona/listar`, persona);
  }

  get(){
    //debo mejorar esto para pasar la base_url como el profe  :/
    return this.http.get<any>(`http://localhost:10300/persona/listar`);
  }
  //Metodo para capturar el id de la persona (grid)
  getPersonaId(id: number){
    return this.http.get<Persona>(this.Url+"/"+id);

  }
}
