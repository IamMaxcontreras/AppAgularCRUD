import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})

//Editar
export class EditService {

  constructor(private http:HttpClient) { }
  post(persona: object = {}){
    //debo mejorar esto para pasar la base_url como el profe  :/
    return this.http.put<any>(`http://localhost:10300/persona/actualizar`, persona);
    //return this.http.request('update', environment.base_Url + 'actualizar', {
  }
}

//creo mi interface con la estructura de la tabla
export interface Persona{
  id:number;
  nombre:string;
  apellidos:string;
  idSexo:number;
  edad:number;
}
  
