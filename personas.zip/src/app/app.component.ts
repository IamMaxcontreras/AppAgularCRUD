import {
  Component, OnInit
} from '@angular/core';
import {
  Router
} from '@angular/router';
import {
  RequestService,
} from './Service/request.service';
import {
  EditService,
} from './Service/edit.service';
import {
  ListarService,
} from './Service/listar.service';

import Swal from 'sweetalert2'; // Importación de la librería de Sweetalert2, previamente instalada con 'npm i sweetalert2'
import { THIS_EXPR } from '@angular/compiler/src/output/output_ast';
import { Persona } from './interfaces/persona.interface';
import { EliminarService } from './Service/eliminar.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'personas';

  constructor(private router: Router, private request: RequestService, private edit: EditService, private listar: ListarService, private eliminar:EliminarService) {}
  Listar() {
    this.router.navigate(["listar"]);
    
  }
  Nuevo() {
    //this.router.navigate(["agregar"]);
   
    this.addDataToDB();
  }

  //Agregar

  async addDataToDB() {
    const {
      value: formValues
    } = await Swal.fire({
      title: 'Agregar Persona',
      html: 
      //uso html para agregar las cajas al popup
      `
        <input id="swal-input2" class="swal2-input" placeholder="Ingrese su nombre..">
        <input id="swal-input3" class="swal2-input" placeholder="Ingrese su apellidos..">
        <input id="swal-input4" class="swal2-input" placeholder="Ingrese su sexoId..">
        <input id="swal-input5" class="swal2-input" placeholder="Ingrese su edad..">
      `,
      focusConfirm: false,
      confirmButtonText: 'Agregar',
      showCancelButton: true,
      cancelButtonText: 'Cancelar',
      preConfirm: () => { // Le paso los datos a la variable formValues
        return [
          // Obtengo el valor para cada elemento del Popup con js y lo deja en una posición 
          (document.getElementById('swal-input2') as HTMLInputElement).value, 
          (document.getElementById('swal-input3') as HTMLInputElement).value,
          (document.getElementById('swal-input4') as HTMLInputElement).value,
          (document.getElementById('swal-input5') as HTMLInputElement).value,
        ]
      }
    })

    if (formValues) {
      //Swal.fire(JSON.stringify(formValues));
      const p = {
        nombre: formValues[0],
        apellidos: formValues[1],
        idSexo: formValues[2],
        edad: formValues[3]
      };
      
      // Envío el objeto al servicio
      this.request.post(p).subscribe(console.log); 
    }
  }
}