//creo mi interface con la estructura de la tabla
export interface Persona{
    id:number;
    nombre:string;
    apellidos:string;
    idSexo:number;
    edad:number;
}
   