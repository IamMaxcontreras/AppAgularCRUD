export const environment = {
  production: true,
  base_Url: 'http://localhost:10300/persona/'
};
